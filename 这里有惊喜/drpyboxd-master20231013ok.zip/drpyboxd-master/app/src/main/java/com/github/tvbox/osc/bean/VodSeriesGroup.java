package com.github.tvbox.osc.bean;

public class VodSeriesGroup {
    public String name;
    public boolean selected = false;

    public VodSeriesGroup(String name) {
        this.name = name;
    }
}
