package com.github.tvbox.osc.player;

public class TrackInfoBean {
    //流ID
    public int trackId;
    //渲染器ID（exo）
    public int renderId;
    //分组ID（exo）
    public int trackGroupId;
    public String name;
    public String language;
    public boolean selected;
}
